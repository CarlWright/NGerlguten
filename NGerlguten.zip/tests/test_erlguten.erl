-module (test_erlguten).

-include_lib ("eunit/include/eunit.hrl").

