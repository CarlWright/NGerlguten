-module (test_erlguten_afm).


-include_lib ("eunit/include/eunit.hrl").

