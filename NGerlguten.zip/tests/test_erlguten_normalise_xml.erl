-module (test_erlguten_normalise_xml).

-include_lib ("eunit/include/eunit.hrl").

